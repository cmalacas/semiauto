<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TireTech extends Model
{
    use HasFactory;

    protected $table = 'tire_techs';
}
