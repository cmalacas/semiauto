

<div class="relative overflow-x-auto">
    <table id="vital-stat-table" class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
        <thead class="text-xs text-gray-700 uppercase">
            <tr>

                <?php $__currentLoopData = $cols; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <th scope="col" class="px-6 py-3">
                    <?php echo e($c); ?>

                </th>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                
            </tr>
        </thead>
        <tbody>

            <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr class="bg-white border-b">
                <th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                    <?php echo e($r->store_id); ?>

                </th>
                <td class="px-6 py-4">
                    --
                </td>
                <td class="px-6 py-4">
                    <?php echo e($r->PR_WK_COR); ?>

                </td>
                <td class="px-6 py-4">
                   <?php echo e($r->CUR_WK_COR); ?>

                </td>

                <td>
                    <?php echo e($r->STRE_OPEN_DATE); ?>

                </td>
                
                <td>
                    <?php echo e($r->WKS_OPEN); ?>

                </td>
                <td>
                    <?php echo e($r->ANDER_EQUIV); ?>

        </td>
        <td>
            <?php echo e($r->ANDER_PCT_COMP); ?>

        </td>
        <td>
            <?php echo e($r->WK_PAY_OFF); ?>

        </td>
        <td>
            <?php echo e($r->CUST_RENT); ?>

        </td>
        <td>
            <?php echo e($r->NEW_AGR); ?>

        </td>
        <td>
            <?php echo e($r->CASH_SALES); ?>

        </td>
        <td>
            <?php echo e($r->SERVICE_REVENUE); ?>

        </td>
        <td>
            <?php echo e($r->PCT_MARGIN); ?>

        </td>
        <td>
            <?php echo e($r->PCT_CUST_RENT); ?>

        </td>
        <td>
            <?php echo e($r->PCT_CUST_RENT_YEAR); ?>

        </td>
        <td>
            <?php echo e($r->AVG_TURN); ?>

        </td>
        <td>
            <?php echo e($r->SAT_CLOSE); ?>

        </td>
        <td>
            <?php echo e($r->SAT_CLOSE_7); ?>

        </td>
        <td>
            <?php echo e($r->SAT_CLOSE_14); ?>

        </td>
        <td>
            <?php echo e($r->SAT_CLOSE_21); ?>

        </td>
        <td>
            <?php echo e($r->SAT_CLOSE_30); ?>

        </td>
        <td>
            <?php echo e($r->SAT_CLOSE_OVR30); ?>

        </td>
        <td>
            <?php echo e($r->SKIPS); ?>

        </td>
        <td>
            <?php echo e($r->SKIP_RATIO); ?>

        </td>
        <td>
            <?php echo e($r->SKIP_RATIO_MONTH); ?>

        </td>
        <td>
            <?php echo e($r->REPOS); ?>

        </td>
        <td>
            <?php echo e($r->ALIGN_PCT); ?>

        </td>
        <td>
            <?php echo e($r->NEWALIGN_PCT); ?>

        </td>
        <td>
            <?php echo e($r->AUTOPAY_PCT); ?>

        </td>
        <td>
            <?php echo e($r->NEW_AUTOPAY_PCT); ?>

        </td>
        <td>
            <?php echo e($r->AGR_LDW_PCT); ?>

        </td>
        <td>
            <?php echo e($r->AGR_CLUB_PCT); ?>

        </td>
        <td>
            <?php echo e($r->AGR_NEWCLUB_PCT); ?>

        </td>
        <td>
            <?php echo e($r->INV_PURCH_LW); ?>

        </td>
        <td>
            <?php echo e($r->INV_SOLD_LW); ?>

        </td>
        <td>
            <?php echo e($r->TOT_IDLE_INV); ?>

        </td>
        <td>
            <?php echo e($r->PCT_IDLE_USED); ?>

        </td>
        <td>
            <?php echo e($r->IDLE_OVER_45); ?>

        </td>
        <td>
            <?php echo e($r->IDLE_OVER_90); ?>

        </td>
        <td>
            <?php echo e($r->IDLE_OVER_180); ?>

        </td>
        <td>
            <?php echo e($r->PCTFREETIME); ?>

        </td>
        <td>
            <?php echo e($r->TOT_ADV_PAY); ?>

        </td>
        <td>
            <?php echo e($r->NEG_PYMT); ?>

        </td>
        <td>
            <?php echo e($r->AVG_ITEM_AGR); ?>

        </td>
        <td>
            <?php echo e($r->AVG_AGR_CUST); ?>

        </td>
        <td>
            <?php echo e($r->DUP_CUST); ?>

        </td>
        <td>
            <?php echo e($r->FREEDAYS); ?>

        </td>
        <td>
            <?php echo e($r->WK_PROMO_DOLLARS); ?>

        </td>
        <td>
            <?php echo e($r->WK_PROMO_CUSTS); ?>

        </td>
        <td>
            <?php echo e($r->PROMO_CUST_RENT_RATIO); ?>

        </td>
        <td>
            <?php echo e($r->WK_AVG_PROMO_CUST); ?>

        </td>
        <td>
            <?php echo e($r->AVG_WKS_TO_PO); ?>

        </td>
        <td>
            <?php echo e($r->PCT_WITH_INSPECTION); ?>

        </td>
        <td>
            <?php echo e($r->PCT_ESTIMATE); ?>

        </td>
        <td>
            <?php echo e($r->PCT_CONVERSION); ?>

        </td>
        <td>
            <?php echo e($r->PR_WK_SOR); ?>

        </td>
        <td>
            <?php echo e($r->CUR_WK_SOR); ?>

        </td>
        <td>
            <?php echo e($r->wK_SVC_PAYOFF); ?>

        </td>
        <td>
            <?php echo e($r->WK_SVC_SKIP); ?>

        </td>
        <td>
            <?php echo e($r->SVC_WK_REV); ?>

        </td>
        <td>
            <?php echo e($r->SVC_CASH_SALES); ?>

        </td>
        <td>
            <?php echo e($r->SVC_SAT_CLOSE); ?>

        </td>
        <td>
            <?php echo e($r->SVC_SAT_CLOSE_7); ?>

        </td>
        <td>
            <?php echo e($r->SVC_SAT_CLOSE_14); ?>

        </td>
        <td>
            <?php echo e($r->SVC_SAT_CLOSE_21); ?>

        </td>
        <td>
            <?php echo e($r->SVC_SAT_CLOSE_30); ?>

        </td>
        <td>
            <?php echo e($r->SVC_SAT_CLOSE_OVR30); ?>

        </td>
        <td>
            <?php echo e($r->NUMOVERRIDES); ?>

        </td>
        <td>
            <?php echo e($r->OVERRIDEAMT); ?>

        </td>
        <td>
            <?php echo e($r->NUMDISPOSED); ?>

        </td>
        <td>
            <?php echo e($r->NUMMISCEXP); ?>

        </td>
        <td>
            <?php echo e($r->MISCEXPAMOUNT); ?>

        </td>
        <td>
            <?php echo e($r->NUMMISCCLUB); ?>

        </td>
        <td>
            <?php echo e($r->TPMSCOUNTSALES); ?>

        </td>
        <td>
            <?php echo e($r->TPMSSALEAMT); ?>

        </td>
        <td>
            <?php echo e($r->NEW_AGR); ?>

        </td>
        <td>
            <?php echo e($r->AOR); ?>

        </td>
            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </tbody>
    </table>
</div>
<?php /**PATH /Users/panok/projects/semiauto/www/resources/views/import/table.blade.php ENDPATH**/ ?>